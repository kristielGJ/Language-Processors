package lpl.ast;

public class TypeInt extends Type {
    
}
