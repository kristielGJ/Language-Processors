package lpl.ast;

public class PrimaryExpIsnull extends PrimaryExp {

    public final PrimaryExp e;

    public PrimaryExpIsnull(PrimaryExp e) {
        this.e = e;
    }

}
