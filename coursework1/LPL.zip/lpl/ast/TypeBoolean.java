package lpl.ast;

public class TypeBoolean extends Type {
    
    @Override
    public String toString() {
        return "bool";
    }
}
