package lpl.ast;

public class PrimaryExpFalse extends PrimaryExp {

}
