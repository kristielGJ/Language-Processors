package lpl.ast;

public class TypeUnit extends Type {
    
}
