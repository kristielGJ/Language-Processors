package lpl.ast;

public class PrimaryExpTrue extends PrimaryExp {

}
